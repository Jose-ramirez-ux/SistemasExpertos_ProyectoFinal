package com.fet.estudio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecoBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
